<?php
// login.php (root) - auto-login via remember cookie + set remember cookie only when checked

require_once __DIR__ . '/db.php';

// helper: compute HMAC token for a given user id
function remember_token_for($user_id) {
    if (!defined('AUTH_SECRET')) {
        define('AUTH_SECRET', 'change_this_to_a_random_string_32_chars_long_!@#');
    }
    return hash_hmac('sha256', (string)$user_id, AUTH_SECRET);
}

// Auto-login via cookie if session not set (must run before any output)
if (!isset($_SESSION['loggedin']) && isset($_COOKIE['rememberme'])) {
    $val = $_COOKIE['rememberme']; // format: base64(user_id):hmac
    $parts = explode(':', $val);
    if (count($parts) === 2) {
        $uid_b64 = $parts[0];
        $hmac = $parts[1];
        $uid = base64_decode($uid_b64);
        if ($uid && hash_equals(remember_token_for($uid), $hmac)) {
            $stmt = $conn->prepare("SELECT id, fname, role FROM users WHERE id = ? LIMIT 1");
            $stmt->bind_param("i", $uid);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows === 1) {
                $row = $result->fetch_assoc();
                $_SESSION['loggedin'] = true;
                $_SESSION['id'] = $row['id'];
                $_SESSION['fname'] = $row['fname'];
                $_SESSION['role'] = $row['role'] ?? 'user';
                header("Location: dashboard.php");
                exit;
            }
            $stmt->close();
        } else {
            // invalid cookie -> remove it
            setcookie('rememberme', '', time() - 3600, "/", "", false, true);
        }
    }
}

// include header (safe after possible redirect)
include __DIR__ . '/header.php';

$message = '';

// Handle login POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $remember = isset($_POST['remember']) ? true : false;

    if ($email === '' || $password === '') {
        $message = 'Please enter both email and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email address.';
    } else {
        try {
            $sql = "SELECT id, fname, password, role FROM users WHERE email = ? LIMIT 1";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Prepare failed");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id, $fname, $hashed_password, $role);
                $stmt->fetch();

                if ($hashed_password !== null && password_verify($password, (string)$hashed_password)) {
                    $_SESSION['loggedin'] = true;
                    $_SESSION['id'] = $id;
                    $_SESSION['fname'] = $fname;
                    $_SESSION['role'] = $role ?? 'user';

                    // If "remember me" checked -> set cookie
                    if ($remember) {
                        $uid = (int)$id;
                        $token = remember_token_for($uid);
                        $value = base64_encode($uid) . ':' . $token;
                        // 30 days, HttpOnly
                        setcookie('rememberme', $value, time() + (30*24*60*60), "/", "", false, true);
                    }

                    header("Location: dashboard.php");
                    exit;
                } else {
                    $message = "The password you entered was not valid.";
                }
            } else {
                $message = "No account found with that email.";
            }

            $stmt->close();
        } catch (Exception $e) {
            $message = "<div class='alert alert-danger'>Database error.</div>";
        }
    }
}
?>

<div class="form-container">
    <h2>Login</h2>
    <?php if ($message): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form action="login.php" method="post">
        <input type="email" name="email" placeholder="Email" required class="form-control">
        <input type="password" name="password" placeholder="Password" required class="form-control">
        <label style="display:block;margin:8px 0;">
            <input type="checkbox" name="remember" value="1"> Remember me
        </label>
        <input type="submit" value="Login" class="btn btn-primary">
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a>.</p>
</div>

<?php include __DIR__ . '/footer.php'; ?>
