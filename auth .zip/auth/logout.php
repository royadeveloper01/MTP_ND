<?php
// logout.php - destroy session + delete rememberme cookie
// Try to include db to ensure session params consistent
$possibleDb = [
    __DIR__ . '/../db.php',
    __DIR__ . '/db.php',
    __DIR__ . '/../db.php'
];
foreach ($possibleDb as $p) {
    if (file_exists($p)) {
        require_once $p;
        break;
    }
}

if (session_status() === PHP_SESSION_NONE) session_start();

// Unset all session variables
$_SESSION = [];

// Destroy session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}

// Destroy session
session_destroy();

// delete remember cookie
setcookie('rememberme', '', time() - 3600, "/", "", false, true);

// Redirect to homepage or login
header("Location: ../index.php");
exit;
